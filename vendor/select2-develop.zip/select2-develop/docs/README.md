Effective beginning September 10, 2017, the Select2 documentation repository is now available at [`select2/docs`](https://github.com/select2/docs).
